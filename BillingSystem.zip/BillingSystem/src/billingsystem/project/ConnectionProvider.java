/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package billingsystem.project;
import java.sql.*;
/**
 *
 * @author madhukar.ranganathan
 */
public class ConnectionProvider {
    public static Connection getCon() {
		try {
			Class.forName("org.postgresql.Driver");
	         Connection con = DriverManager
	            .getConnection("jdbc:postgresql://localhost:5432/bms",
	            "postgres", "password");
	         return con;
		}
		catch(Exception e) {
			return null;
		}
	}
}
